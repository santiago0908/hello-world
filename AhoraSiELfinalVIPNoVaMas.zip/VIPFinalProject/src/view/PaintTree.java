package view;

import java.awt.Color;
import java.util.ArrayList;

import javax.swing.SwingUtilities;
import com.mxgraph.layout.mxCompactTreeLayout;
import com.mxgraph.model.mxCell;
import com.mxgraph.swing.mxGraphComponent;
import com.mxgraph.view.mxGraph;
import VIPModel.N_Ary_Tree;
import VIPModel.Product;
import javafx.embed.swing.SwingNode;

public class PaintTree {
	
	private mxGraphComponent gc;
	
	private SwingNode swingNode;
	
	private mxGraph graph;
	
	public PaintTree() {
		gc = null;
	}
	
	public void createProductTree (N_Ary_Tree tree) {
		
		graph = new mxGraph();
		graph.setCellsEditable(false);

		Object parent = graph.getDefaultParent();
		
		ArrayList<Product> array = tree.getByLevels();
		
		mxCell[] auxObject = new mxCell[array.size()];

		for (int i = 0; i < auxObject.length; i++) {
			
			auxObject[i] = (mxCell) graph.insertVertex(parent, null, array.get(i).getId() + "\n" + array.get(i).getAmount(), 0, 0, 60, 40, "");
			
		}
		
		int index = 1;

		for (int i = 0; i < auxObject.length; i++) {
			for (int j = 0; array.get(i).getSubProducts().size() != 0 && j < array.get(i).getSubProducts().size(); j++) {
				graph.insertEdge(parent, null, "", auxObject[i], auxObject[index]);
				index++;
			}
		}
		
		mxCompactTreeLayout layout = new mxCompactTreeLayout(graph, false);
		layout.setUseBoundingBox(false);
//		layout.setEdgeRouting(false);
		layout.setLevelDistance(30);
		layout.setNodeDistance(10);
		layout.execute(parent);
		
		gc = new mxGraphComponent(graph);
		gc.setEnabled(false);
		gc.setBackground(Color.BLACK);
		swingNode = new SwingNode();
		createAndSetSwingContent(swingNode);
		
	}
	
	private void createAndSetSwingContent (final SwingNode swingNode) {
		
		SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				swingNode.setContent(gc);
			}
		});
		
	}

	public SwingNode getSwingNode() {
		return swingNode;
	}

	public void setSwingNode(SwingNode swingNode) {
		this.swingNode = swingNode;
	}
	
}
