package VIPModel;

import java.util.ArrayList;

public class N_Ary_Tree {

	/**
	 * The root of the tree
	 */
	private Product rootProduct;

	/**
	 * The numbers of levels that the tree will have
	 */
	private int levels;

	/**
	 * The name of the n-ary tree
	 */
	private String name;

	/**
	 * 
	 */
	private int fullSizeTree;

	/**
	 * Creates a n-ary tree (information container)
	 */
	public N_Ary_Tree() {
		rootProduct = null;
		levels = 0;
		name = "Default Name";
		fullSizeTree = 0;
	}

	/**
	 * Creates a n-ary tree (information container)
	 * 
	 * @param levels
	 *            The number of levels the tree will have
	 * @param name
	 *            The tree's name
	 */
	public N_Ary_Tree(int levels, String name) {
		this.name = name;
		this.levels = levels;
		rootProduct = null;
	}

	/**
	 * 
	 * @return
	 */
	public int getLevels() {
		return levels;
	}

	/**
	 * 
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * 
	 * @param levels
	 */
	public void setLevels(int levels) {
		this.levels = levels;
	}

	/**
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * 
	 * @return
	 */
	public Product getRootProduct() {
		return rootProduct;
	}

	/**
	 * 
	 * @param rootProduct
	 */
	public void setRootProduct(Product rootProduct) {
		this.rootProduct = rootProduct;
	}

	/**
	 * 
	 * @return
	 */
	public int getFullSizeTree() {
		return fullSizeTree;
	}

	/**
	 * 
	 * @param fullSizeTree
	 */
	public void setFullSizeTree(int fullSizeTree) {
		this.fullSizeTree = fullSizeTree;
	}

	/**
	 * This method initializes the root.
	 * 
	 * @param name
	 *            Product name father
	 * @param productionTime
	 *            The time to make the product father
	 * @param timeUnit
	 *            The unit time in which the product father is made.
	 */
	public void insertProduct(String id, String name, int productionTime, String timeUnit) {
		rootProduct = new Product(null, id, name, productionTime, 1, timeUnit);
		fullSizeTree++;
	}
	
	
	public void insertProductMRP (Product father, String id, String name, int productionTime, int amount, String timeUnit, int initialInv, int securiInv, ArrayList<String> date, ArrayList<Integer> programDelivery) {
		
		rootProduct = new Product(father, id, name, productionTime, amount, timeUnit, initialInv, securiInv);
		
		if(programDelivery != null) {
			for (int i = 0; i < programDelivery.size(); i++) {
				rootProduct.insertProgramDelivery(date.get(i), programDelivery.get(i));
			}
		}
		
		fullSizeTree++;
 		
	}

	/**
	 * This method insert subproducts to a product father
	 * 
	 * @param fatherName
	 *            The name of the product to which the new product is inserted
	 * @param name
	 *            The name of the product to be inserted
	 * @param productionTime
	 *            The time necessary to make the product to be inserted
	 * @param amount
	 *            The amount of this product to build a father
	 * @param timeUnit
	 *            The product's time unit
	 */
	public void insertSubProduct(String fatherName, String id, String name, int productionTime, int amount, String timeUnit) {

		Product fatherProduct = rootProduct.search(fatherName);

		if (fatherProduct != null) {
			Product subProduct = new Product(fatherProduct, id, name, productionTime, amount, timeUnit);
			fatherProduct.insertProduct(subProduct);
			fullSizeTree++;
		}

	}
	
	public void insertSubProductMRP(String fatherName, String id, String name, int productionTime, int amount, String timeUnit, int initialInv, int securiInv, ArrayList<String> date, ArrayList<Integer> programDelivery) {

		Product fatherProduct = rootProduct.search(fatherName);

		if (fatherProduct != null) {
			Product subProduct = new Product(fatherProduct, id, name, productionTime, amount, timeUnit, initialInv, securiInv);
			fatherProduct.insertProduct(subProduct);
			
			if (programDelivery != null) {
				for (int i = 0; i < programDelivery.size(); i++) {
					subProduct.insertProgramDelivery(date.get(i), programDelivery.get(i));
				}
			}
			fullSizeTree++;
		}

	}
	
	public Product search (String id) {
		
		Product product = rootProduct.search(id);

		if (product != null) {
			return product;
		}
		
		return null;
		
	}

	public ArrayList<Product> inorder() {

		ArrayList<Product> products = new ArrayList<>();

		if (rootProduct != null) {
			rootProduct.inorder(products);
		}
		return products;
	}

	/**
	 * 
	 * @return
	 */
	public ArrayList<Product> getPreorder() {
		ArrayList<Product> products = new ArrayList<>();

		if (rootProduct != null) {
			rootProduct.preorder(products);
		}

		return products;
	}

	/**
	 * 
	 * @return
	 */
	public ArrayList<Product> getPostorder() {
		ArrayList<Product> products = new ArrayList<>();
		rootProduct.postorder(products);
		return products;
	}

	/**
	 * 
	 * @return
	 */
	public ArrayList<Product> getByLevels() {

		ArrayList<Product> products = new ArrayList<>();

		if (rootProduct != null) {
			rootProduct.byLevels(products);
		}

		return products;

	}

}