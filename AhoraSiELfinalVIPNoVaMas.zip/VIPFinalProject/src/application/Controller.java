package application;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import VIPModel.MRP;
import VIPModel.Product;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;
import view.PaintTree;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Controller {

	// Escenarios

	public static Stage productF;
	public static Stage productS;
	public static Stage productFaMRP;
	public static Stage MRPAddorders;
	public static Stage MRPview;
	public static Stage productSonMRP;
	public static Stage MRPscheduleDelivery;

	private static MRP mrp;

	private PaintTree paintProductTree;

	// Pantalla Inicial

	@FXML
	private Hyperlink linkD;
	@FXML
	private Button btnMod4;
	@FXML
	private Button btnMod3;
	@FXML
	private Button btnMod2;
	@FXML
	private Button btnMod1;
	@FXML
	private ImageView vipPicture;
	@FXML
	private ImageView icesiPicture;

	/**
	 * MRPproductF.fxml TODO
	 */

	@FXML
	private Button btnScheduledDelivieres;
	@FXML
	private ComboBox<String> comboTimeUnit;
	@FXML
	private Button btnOrders;
	@FXML
	private TextField txtFatherIdentifierMRP;
	@FXML
	private Button btnAddSubMRP;
	@FXML
	private Button btnHomeMRP;
	@FXML
	private Button btnResetMRP;
	@FXML
	private Button btnFinishMRP;
	@FXML
	private TextField txtFatherProductNameMRP;
	@FXML
	private TextField txtFatherPLeadTimeMRP;
	@FXML
	private TextField txtInicialInventoryFather;
	@FXML
	private TextField txtSecurityInventory;

	private static ArrayList<Integer> programDelivery;
	private static ArrayList<String> date;
	private static ArrayList<Integer> rqb;
	private static ArrayList<String> dateRqb;

	@FXML
	void listTimeUnitMRP(ActionEvent event) {
	}

	@FXML
	void addSubMRP(ActionEvent event) {
		productFaMRP.close();

		mrp.inserProductMRP("", txtFatherIdentifierMRP.getText(), txtFatherProductNameMRP.getText(),
				Integer.parseInt(txtFatherPLeadTimeMRP.getText()), 1, comboTimeUnit.getValue(),
				Integer.parseInt(txtInicialInventoryFather.getText()),
				Integer.parseInt(txtInicialInventoryFather.getText()), date, programDelivery);

		Parent root;
		try {
			productSonMRP = new Stage();
			root = FXMLLoader.load(getClass().getResource("/view/MRPproduct_S.fxml"));
			Scene scene = new Scene(root);
			Image icon = new Image("file:./img/iconnave.png");
			productSonMRP.setScene(scene);
			productSonMRP.getIcons().add(icon);
			productSonMRP.setTitle("  .::Load Orders::.");
			productSonMRP.setMaximized(false);
			productSonMRP.initModality(Modality.APPLICATION_MODAL);
			productSonMRP.setResizable(false);

			actuCombFatherIdentifier();
			productSonMRP.show();

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@FXML
	void btnActionOrder(ActionEvent event) {
		Parent root;
		try {
			rqb = new ArrayList<>();
			dateRqb = new ArrayList<>();
			MRPAddorders = new Stage();
			initilizeMRPaddOrders();
			root = FXMLLoader.load(getClass().getResource("/view/MRPAddorders.fxml"));
			Scene scene = new Scene(root);
			Image icon = new Image("file:./img/iconnave.png");
			MRPAddorders.setScene(scene);
			MRPAddorders.getIcons().add(icon);
			MRPAddorders.setTitle("  .::Load Orders::.");
			MRPAddorders.setMaximized(false);
			MRPAddorders.initModality(Modality.APPLICATION_MODAL);
			MRPAddorders.setResizable(false);
			MRPAddorders.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	void resetAllMRP(ActionEvent event) {
		productFaMRP.close();
	}

	@FXML
	void finishMRP(ActionEvent event) {

		if (!txtFatherIdentifierMRP.getText().equals("")) {
			mrp.inserProductMRP("", txtFatherIdentifierMRP.getText(), txtFatherProductNameMRP.getText(),
					Integer.parseInt(txtFatherPLeadTimeMRP.getText()), 1, comboTimeUnit.getValue(),
					Integer.parseInt(txtSecurityInventory.getText()),
					Integer.parseInt(txtInicialInventoryFather.getText()), date, programDelivery);
		}
		MRPview = new Stage();
		Parent root;
		try {
			root = FXMLLoader.load(getClass().getResource("/view/MRPview.fxml"));
			Scene scene = new Scene(root);
			Image icon = new Image("file:./img/iconnave.png");
			MRPview.setScene(scene);
			MRPview.getIcons().add(icon);
			MRPview.setTitle("  .::Load Orders::.");
			MRPview.setMaximized(false);
			MRPview.initModality(Modality.APPLICATION_MODAL);
			MRPview.setResizable(false);
			MRPview.show();
		} catch (IOException e) {
			e.printStackTrace();
		}

		productFaMRP.close();
	}

	@FXML
	void goHomeMRP(ActionEvent event) {
		productFaMRP.close();
	}

	/*
	 * ULTIMA VENTANA DE DECISION MRP
	 */
	@FXML
	private Button btnMrpBasic;

	@FXML
	private Button btnMrpNet;

	@FXML
	void basicMRP(ActionEvent event) {
		if (!comboFatherPIdentifierMRP.getValue().equals("")) {
			mrp.inserProductMRP(comboFatherPIdentifierMRP.getValue(), txtSubPIdentifierMRP.getText(),
					txtSubProductNameMRP.getText(), Integer.parseInt(txtSubPLeadTimeMRPSon.getText()),
					Integer.parseInt(txtAmountManufactureFather.getText()), "",
					Integer.parseInt(txtInitialInventorySon.getText()),
					Integer.parseInt(txtSecurityInventorySon.getText()), dateSon, programDeliverySon);
		}
		MRPview = new Stage();
		Parent root;
		try {
			root = FXMLLoader.load(getClass().getResource("/view/MRPview.fxml"));
			Scene scene = new Scene(root);
			Image icon = new Image("file:./img/iconnave.png");
			MRPview.setScene(scene);
			MRPview.getIcons().add(icon);
			MRPview.setTitle("  .::Load Orders::.");
			MRPview.setMaximized(false);
			MRPview.initModality(Modality.APPLICATION_MODAL);
			MRPview.setResizable(false);
			MRPview.show();
		} catch (IOException e) {
			e.printStackTrace();
		}

		productFaMRP.close();

	}

	@FXML
	void NetMrp(ActionEvent event) {

		if (!comboFatherPIdentifierMRP.getValue().equals("")) {
			mrp.inserProductMRP(comboFatherPIdentifierMRP.getValue(), txtSubPIdentifierMRP.getText(),
					txtSubProductNameMRP.getText(), Integer.parseInt(txtSubPLeadTimeMRPSon.getText()),
					Integer.parseInt(txtAmountManufactureFather.getText()), "",
					Integer.parseInt(txtInitialInventorySon.getText()),
					Integer.parseInt(txtSecurityInventorySon.getText()), dateSon, programDeliverySon);
		}
		MRPview = new Stage();
		Parent root;
		try {
			root = FXMLLoader.load(getClass().getResource("/view/MRPview.fxml"));
			Scene scene = new Scene(root);
			Image icon = new Image("file:./img/iconnave.png");
			MRPview.setScene(scene);
			MRPview.getIcons().add(icon);
			MRPview.setTitle("  .::Load Orders::.");
			MRPview.setMaximized(false);
			MRPview.initModality(Modality.APPLICATION_MODAL);
			MRPview.setResizable(false);
			MRPview.show();
		} catch (IOException e) {
			e.printStackTrace();
		}

		productFaMRP.close();

	}

	@FXML
	void scheduledDelivieres(ActionEvent event) {

		Parent root;
		try {
			programDelivery = new ArrayList<>();
			date = new ArrayList<>();
			MRPscheduleDelivery = new Stage();
			root = FXMLLoader.load(getClass().getResource("/view/MRPScheduleDelivery.fxml"));
			Scene scene = new Scene(root);
			Image icon = new Image("file:./img/iconnave.png");
			MRPscheduleDelivery.setScene(scene);
			MRPscheduleDelivery.getIcons().add(icon);
			MRPscheduleDelivery.setTitle("  .::Load Orders::.");
			MRPscheduleDelivery.setMaximized(false);
			MRPscheduleDelivery.initModality(Modality.APPLICATION_MODAL);
			MRPscheduleDelivery.setResizable(false);
			MRPscheduleDelivery.show();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/**
	 * MRPscheduleDelivery TODO
	 */
	@FXML
	private Button btnContinueAfterSchedule;

	@FXML
	private Button btnAddSheduleDelivery;

	@FXML
	private TextField lblQuantityScheduled;

	@FXML
	private TextField lblArrivalDateScheduled;

	@FXML
	void addSheduleDelivery(ActionEvent event) {

		programDelivery.add(Integer.parseInt(lblQuantityScheduled.getText()));
		date.add(lblArrivalDateScheduled.getText());

		lblQuantityScheduled.setText("");
		lblArrivalDateScheduled.setText("");
	}

	@FXML
	void continueAfterSchedule(ActionEvent event) {

		if (!lblQuantityScheduled.getText().equals("")) {
			programDelivery.add(Integer.parseInt(lblQuantityScheduled.getText()));
			date.add(lblArrivalDateScheduled.getText());
		}

		MRPscheduleDelivery.close();

	}

	/**
	 * MRPaddOrders TODO
	 */

	@FXML
	private Button btnAddOrder;
	@FXML
	private Button btnContinueAfterOrder;
	@FXML
	private TextField lblOrderDeliveryMRP;
	@FXML
	private TextField lblQuantityOrderMRP;

	@FXML
	void addOrder(ActionEvent event) {
		rqb.add(Integer.parseInt(lblQuantityOrderMRP.getText()));
		dateRqb.add(lblOrderDeliveryMRP.getText());

		lblQuantityOrderMRP.setText("");
		lblOrderDeliveryMRP.setText("");
	}

	@FXML
	void continueFinishAddOrder(ActionEvent event) {

		if (!lblQuantityOrderMRP.getText().equals("")) {
			rqb.add(Integer.parseInt(lblQuantityOrderMRP.getText()));
			dateRqb.add(lblOrderDeliveryMRP.getText());
		}

		MRPAddorders.close();
	}

	/**
	 * MRPProduct_Son TODO
	 */

	@FXML
	private TextField txtAmountManufactureFather;

	@FXML
	private ComboBox<String> comboFatherPIdentifierMRP;

	@FXML
	private Button btnAddScheduledDelivery;

	@FXML
	private TextField txtSubPLeadTimeMRPSon;

	@FXML
	private TextField txtInitialInventorySon;

	@FXML
	private TextField txtSubProductNameMRP;

	@FXML
	private Button btnAddSubProduct;

	@FXML
	private Button btnHomeMRPSon;

	@FXML
	private TextField txtSecurityInventorySon;

	@FXML
	private Button btnResetSon;

	@FXML
	private Button btnFinishMRPSon;

	@FXML
	private TextField txtSubPIdentifierMRP;

	private ArrayList<String> dateSon;

	private ArrayList<Integer> programDeliverySon;

	@FXML
	void addSubProductSon(ActionEvent event) {

		mrp.inserProductMRP(comboFatherPIdentifierMRP.getValue(), txtSubPIdentifierMRP.getText(),
				txtSubProductNameMRP.getText(), Integer.parseInt(txtSubPLeadTimeMRPSon.getText()),
				Integer.parseInt(txtAmountManufactureFather.getText()), "",
				Integer.parseInt(txtInitialInventorySon.getText()), Integer.parseInt(txtSecurityInventorySon.getText()),
				dateSon, programDeliverySon);

		txtInitialInventorySon.clear();
		txtSecurityInventorySon.clear();
		txtSubProductNameMRP.clear();
		txtAmountManufactureFather.clear();
		txtSubPLeadTimeMRPSon.clear();
		txtSubPIdentifierMRP.clear();

		actuCombFatherIdentifier();
	}

	public void actuCombFatherIdentifier() {

		ObservableList<String> combList = FXCollections.observableArrayList();

		ArrayList<Product> arr = mrp.getN_Ary_Tree().getByLevels();

		for (int i = 0; i < arr.size(); i++) {
			combList.add(arr.get(i).getId());
		}

		comboFatherPIdentifierMRP.setItems(combList);
	}

	@FXML
	void btnFinishMRPSon(ActionEvent event) {
		if (!comboFatherPIdentifierMRP.getValue().equals("")) {
			mrp.inserProductMRP(comboFatherPIdentifierMRP.getValue(), txtSubPIdentifierMRP.getText(),
					txtSubProductNameMRP.getText(), Integer.parseInt(txtSubPLeadTimeMRPSon.getText()),
					Integer.parseInt(txtAmountManufactureFather.getText()), "",
					Integer.parseInt(txtInitialInventorySon.getText()),
					Integer.parseInt(txtSecurityInventorySon.getText()), dateSon, programDeliverySon);
		}
		MRPview = new Stage();
		Parent root;
		try {
			root = FXMLLoader.load(getClass().getResource("/view/MRPview.fxml"));
			Scene scene = new Scene(root);
			Image icon = new Image("file:./img/iconnave.png");
			MRPview.setScene(scene);
			MRPview.getIcons().add(icon);
			MRPview.setTitle("  .::Load Orders::.");
			MRPview.setMaximized(false);
			MRPview.initModality(Modality.APPLICATION_MODAL);
			MRPview.setResizable(false);
			MRPview.show();
		} catch (IOException e) {
			e.printStackTrace();
		}

		productFaMRP.close();
	}

	/**
	 * productF.fxml TODO
	 */

	@FXML
	private TextField fatherPIdentifier;
	@FXML
	private TextField fatherPName;
	@FXML
	private Button btnAddSub;
	@FXML
	private TextField fatherPLT;
	@FXML
	private ComboBox<String> timeUnitSelect;
	@FXML
	private Button btnFinish;
	@FXML
	private Button btnReset;
	@FXML
	private Button btnHome;

	@FXML
	void addSub(ActionEvent event) throws Exception {
		mrp.insertProduct("", fatherPIdentifier.getText(), fatherPName.getText(), Integer.parseInt(fatherPLT.getText()),
				timeUnitSelect.getValue(), 1);

		productF.close();

		productS = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/view/productSon.fxml"));
		Scene scene = new Scene(root);
		Image icon = new Image("file:./img/iconnave.png");
		productS.setScene(scene);
		productS.getIcons().add(icon);
		productS.setTitle("  .::Load Father Product Information::.");
		productS.setMaximized(false);
		productS.initModality(Modality.APPLICATION_MODAL);
		productS.setResizable(false);
		productS.show();

//	btnAddSub.setOnAction(e -> {
//		System.out.println("Ho");
//		productF.close();
//		});

	}

	@FXML
	void resetAll(ActionEvent event) {
		fatherPIdentifier.clear();
		fatherPName.clear();
		fatherPLT.clear();
		timeUnitSelect.getSelectionModel().select(2);
	}

	@FXML
	void finishFatherProductInformation(ActionEvent event) throws Exception {
		if (!fatherPIdentifier.getText().equals("")) {
			mrp.insertProduct("", fatherPIdentifier.getText(), fatherPName.getText(),
					Integer.parseInt(fatherPLT.getText()), timeUnitSelect.getValue(), 1);
		}

		Stage window = new Stage();

		Image icon = new Image("file:./img/iconnave.png");
		window.getIcons().add(icon);

		window.initModality(Modality.APPLICATION_MODAL);
		window.setTitle("!!!");
		window.setMinWidth(200);
		window.setMinHeight(100);

		Label label = new Label();
		label.setText("Do you want to continue?");

		Button yesButton = new Button("Yes");
		Button backButton = new Button("Back");
		backButton.setOnAction(e -> {
			window.close();
		});
		yesButton.setOnAction(e -> {

			Parent root;
			try {
				root = FXMLLoader.load(getClass().getResource("/view/treeWindow.fxml"));
				Scene sceneTree = new Scene(root);
				Stage treeWindow = new Stage();
				treeWindow.setScene(sceneTree);
				treeWindow.show();
			} catch (IOException e1) {
				e1.printStackTrace();
			}

			window.close();
		});

		VBox layout = new VBox(12);
		layout.getChildren().addAll(label, yesButton, backButton);
		layout.setAlignment(Pos.CENTER);

		Scene scene = new Scene(layout, Color.RED);

		scene.setFill(Color.BLACK);
		window.setScene(scene);
		window.showAndWait();

	}

	@FXML
	void goHome(ActionEvent event) {
		productF.close();
	}

	// -----------------------------------------------------------------------

	/**
	 * ProductSon.fxml TODO
	 */
	@FXML
	private TextField sonPLT1;
	@FXML
	private Button btnFinish2;
	@FXML
	private Button btnHome2;
	@FXML
	private Button btnAddSub2;
	@FXML
	private TextField sonPName;
	@FXML
	private Button btnReset2;
	@FXML
	private TextField sonPIdentifier;
	@FXML
	private TextField txtAmount;
	@FXML
	private ComboBox<String> comboParentProductIdentifier;

	public void actuCombo() {

		ObservableList<String> combList = FXCollections.observableArrayList();

		ArrayList<Product> arr = mrp.getN_Ary_Tree().getByLevels();

		for (int i = 0; i < arr.size(); i++) {
			combList.add(arr.get(i).getId());
		}

		comboParentProductIdentifier.setItems(combList);

	}

	@FXML
	public void addSubProduct(ActionEvent event) throws Exception {

		mrp.insertProduct(comboParentProductIdentifier.getValue(), sonPIdentifier.getText(), sonPName.getText(),
				Integer.parseInt(sonPLT1.getText()), timeUnitSelect.getValue(), Integer.parseInt(txtAmount.getText()));

		sonPIdentifier.clear();
		sonPLT1.clear();
		sonPName.clear();
		actuCombo();
	}

	@FXML
	public void resetAll2(ActionEvent event) {
		sonPIdentifier.clear();
		sonPLT1.clear();
		sonPName.clear();

	}

	@FXML
	public void finishProductSonInformation(ActionEvent event) {

		if (!sonPIdentifier.getText().equals("")) {
			mrp.insertProduct(comboParentProductIdentifier.getValue(), sonPIdentifier.getText(), sonPName.getText(),
					Integer.parseInt(sonPLT1.getText()), timeUnitSelect.getValue(),
					Integer.parseInt(txtAmount.getText()));
		}

		Stage window = new Stage();
		Image icon = new Image("file:./img/iconnave.png");
		window.getIcons().add(icon);

		window.initModality(Modality.APPLICATION_MODAL);
		window.setTitle("!!!");
		window.setMinWidth(200);
		window.setMinHeight(100);

		Label label = new Label();
		label.setText("Do you want to continue?");

		Button yesButton = new Button("Yes");
		Button backButton = new Button("Back");
		backButton.setOnAction(e -> {
			window.close();
		});

		yesButton.setOnAction(e -> {

			try {
				Parent root = FXMLLoader.load(getClass().getResource("/view/treeWindow.fxml"));
				Scene sceneTree = new Scene(root);
				Stage treeWindow = new Stage();
				treeWindow.setScene(sceneTree);
				treeWindow.show();

			} catch (IOException e2) {
				e2.printStackTrace();
			}

//			paintProductTree = new PaintTree();
//			treePanel = new AnchorPane();
//			try {
//				paintProductTree.createProductTree(mrp.getN_Ary_Tree(), treePanel);
//			} catch (IOException e1) {
//				e1.printStackTrace();
//			}
			window.close();

		});

		VBox layout = new VBox(12);
		layout.getChildren().addAll(label, yesButton, backButton);
		layout.setAlignment(Pos.CENTER);

		Scene scene = new Scene(layout, Color.RED);

		scene.setFill(Color.BLACK);
		window.setScene(scene);
		window.showAndWait();
	}

	@FXML
	void goHome2(ActionEvent event) {
		productF.close();
		productS.close();
	}

	// ------------------------------------------------

	@FXML
	void showBasicMRP(ActionEvent event) throws Exception {
		initializeModel();
		ObservableList<String> timeUnitList = FXCollections.observableArrayList();
//		timeUnitList.addAll("Hours", "Days", "Weeks", "Months", "Years");
//		comboTimeUnit.setItems(timeUnitList);
//		comboTimeUnit.getSelectionModel().select(2);

		Parent root3 = FXMLLoader.load(getClass().getResource("/view/MRPproductF.fxml"));
		Scene scene3 = new Scene(root3);
		Image icon = new Image("file:./img/iconnave.png");
		productFaMRP.getIcons().add(icon);
		productFaMRP.setScene(scene3);
		productFaMRP.setTitle("  .::Load Father Product Information::.");
		productFaMRP.setMaximized(false);
		productFaMRP.initModality(Modality.APPLICATION_MODAL);
		productFaMRP.setResizable(false);
		productFaMRP.show();

	}

	@FXML
	void showCompleteMRP(ActionEvent event) throws Exception {
		initializeModel();
		ObservableList<String> timeUnitList = FXCollections.observableArrayList();
//		timeUnitList.addAll("Hours", "Days", "Weeks", "Months", "Years");
//		comboTimeUnit.setItems(timeUnitList);
//		comboTimeUnit.getSelectionModel().select(2);

		Parent root3 = FXMLLoader.load(getClass().getResource("/view/MRPproductF.fxml"));
		Scene scene3 = new Scene(root3);
		Image icon = new Image("file:./img/iconnave.png");
		productFaMRP.getIcons().add(icon);
		productFaMRP.setScene(scene3);
		productFaMRP.setTitle("  .::Load Father Product Information::.");
		productFaMRP.setMaximized(false);
		productFaMRP.initModality(Modality.APPLICATION_MODAL);
		productFaMRP.setResizable(false);
		productFaMRP.show();
	}

	@FXML
	void showMRPTree(ActionEvent event) throws Exception {
		productF = new Stage();
		initialize();
		initializeModel();
		Parent root1 = FXMLLoader.load(getClass().getResource("/view/productF.fxml"));
		Scene scene1 = new Scene(root1);
		Image icon = new Image("file:./img/iconnave.png");
		productF.getIcons().add(icon);
		productF.setScene(scene1);
		productF.setTitle("  .::Load Father Product Information::.");
		productF.setMaximized(false);
		productF.setResizable(false);
		productF.show();
	}

	@FXML
	void showVBox4(ActionEvent event) {
		Stage windowAlert = new Stage();
		windowAlert.initModality(Modality.APPLICATION_MODAL);
		windowAlert.setTitle("ALERT");
		windowAlert.setMinWidth(300);
		Label label = new Label();
		label.setText("MRP Neto, aun en proceso...");

		Button closeButton = new Button("OK");
		closeButton.setOnAction(e -> windowAlert.close());

		VBox layout = new VBox(20);
		layout.getChildren().addAll(label, closeButton);
		layout.setAlignment(Pos.CENTER);

		Scene scene = new Scene(layout);
		windowAlert.setScene(scene);
		windowAlert.showAndWait();
	}

	@FXML
	void goLink(ActionEvent event) {
//			linkD.setOnAction((EventHandler<ActionEvent>) new EventHandlerManager(event));

	}

	public void initialize() {
		ObservableList<String> timeUnitList = FXCollections.observableArrayList();
		timeUnitList.addAll("Hours", "Days", "Weeks", "Months", "Years");
		ObservableList<String> levelsList = FXCollections.observableArrayList();
		levelsList.addAll("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15");

		timeUnitSelect.setItems(timeUnitList);

		timeUnitSelect.getSelectionModel().select(2);

		comboTimeUnit.setItems(timeUnitList);
		comboTimeUnit.getSelectionModel().select(2);

		productFaMRP = new Stage();

//		 if (btnFinish.isDisable() == false) {
//			 productF.close();
//		}

//			btnAddSub.setOnAction(e -> {
//				System.out.println("er");
//				productF.close();
//				});

	}

	/**
	 * treeWindow.fxml TODO TODO TODO TODO
	 */
	@FXML
	private BorderPane borderPane;
	@FXML
	private Button btnHomeTree;
	@FXML
	private GridPane gridPaneTop;
	@FXML
	private ScrollPane scrollPane;
	@FXML
	private StackPane treePanel;
	@FXML
	private GridPane gridPaneBottom;
	@FXML
	private Button btnGraph;
	@FXML
	private Pane pane;
	@FXML
	private ImageView img2;
	@FXML
	private ImageView img1;

	public void initializeTreeWindow() {
//		borderPane = new BorderPane();
//		btnHomeTree = new Button();
//		gridPaneTop = new GridPane();
//		gridPaneBottom = new GridPane();
//		scrollPane = new ScrollPane();
//		treePanel = new AnchorPane();
//		btnEditSub = new Button();
//		pane = new Pane();
	}

	@FXML
	void graphTree(ActionEvent event) {

		paintProductTree = new PaintTree();
		paintProductTree.createProductTree(mrp.getN_Ary_Tree());
		treePanel.setAlignment(Pos.CENTER);
		treePanel.getChildren().add(paintProductTree.getSwingNode());
		treePanel.setAlignment(Pos.CENTER);
		StackPane.setAlignment(paintProductTree.getSwingNode(), Pos.CENTER);
	}

	@FXML
	void backHomeTree(ActionEvent event) {

	}

	public void initializeModel() {
		mrp = new MRP();
	}

	public void initilizeMRPaddOrders() {
		lblOrderDeliveryMRP = new TextField();
		lblQuantityOrderMRP = new TextField();
	}

	/**
	 * MRPview TODO
	 */

	@FXML
	private Button btnGenerateProductTree;

	@FXML
	private TabPane TabPane;

	@FXML
	private ScrollPane scrollPaneForMRP;

	private GridPane gridPane;

	private SplitPane[] splitter;

	private ListView<String>[] list;

	private TableView<Integer[]>[] mrpTable;

	private TableColumn[] tableColumns;

	@FXML
	private Button btnGenerateMRP;

	@FXML
	void generateProductTree(ActionEvent event) {

		Parent root;
		try {
			root = FXMLLoader.load(getClass().getResource("/view/treeWindow.fxml"));
			Scene sceneTree = new Scene(root);
			Stage treeWindow = new Stage();
			treeWindow.setScene(sceneTree);
			treeWindow.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@FXML
	void generateMRP(ActionEvent event) {
		generate(mrp, rqb, dateRqb);
	}

	private SplitPane[] aux;

	private void generate(MRP mrp, ArrayList<Integer> rqb, ArrayList<String> dateRqb) {

		gridPane = new GridPane();

		ArrayList<Product> all = mrp.getN_Ary_Tree().getByLevels();

		ArrayList<Integer[][]> allmrp = mrp.allProductsMRP(mrp.getN_Ary_Tree(), rqb, dateRqb);

		tableColumns = new TableColumn[3];

		aux = new SplitPane[all.size()];
		splitter = new SplitPane[all.size()];
		list = new ListView[all.size()];
		mrpTable = new TableView[all.size()];

		for (int i = 0; i < all.size(); i++) {
			Collection<String> lis = new ArrayList<>();
			lis.add("Basic Requirements");
			lis.add("Scheduled Deliverys");
			lis.add("Inventory");
			lis.add("Net Requirements");
			lis.add("Plained Deliverys");
			lis.add("Buying Order");

			ObservableList<String> details = FXCollections.observableArrayList(lis);

			TableView<String> tableView = new TableView<>();
			TableColumn<String, String> col1 = new TableColumn<>();
			tableView.getColumns().addAll(col1);

			col1.setCellValueFactory(data -> new SimpleStringProperty(data.getValue()));
			tableView.setItems(details);
			aux[i] = new SplitPane();
			splitter[i] = new SplitPane();
			splitter[i].setOrientation(Orientation.VERTICAL);
			list[i] = new ListView<>();

			splitter[i].setPrefSize(scrollPaneForMRP.getWidth() - 15, 330);
			splitter[i].setDividerPositions(0.44);

			ObservableList<String> items = FXCollections.observableArrayList("Name: " + all.get(i).getName(),
					"ID: " + all.get(i).getId(), "Level: " + i, "Lead Time: " + all.get(i).getLeadTime(),
					"Security Inventory: " + all.get(i).getSecurityInv(),
					"Initial Inventory: " + all.get(i).getInitialInv());

			list[i].setItems(items);

			ObservableList<Integer[]> itemsTableView = generateData(allmrp.get(i));

			mrpTable[i] = new TableView<>(itemsTableView);

			mrpTable[i].getColumns().addAll(createColumns(allmrp.get(i)));

			aux[i].setDividerPositions(0.22);
			aux[i].getItems().addAll(tableView, mrpTable[i]);

			splitter[i].getItems().addAll(list[i], aux[i]);

			gridPane.add(splitter[i], 0, i);
			scrollPaneForMRP.setContent(gridPane);
		}

	}

	private ArrayList<TableColumn<Integer[], Integer>> createColumns(Integer[][] data) {

		ArrayList<TableColumn<Integer[], Integer>> list = new ArrayList<>();

		for (int i = 0; i < data[0].length; i++) {
			list.add(createColumn(i));
		}

		return list;

	}

	private TableColumn<Integer[], Integer> createColumn(int c) {
		TableColumn<Integer[], Integer> col = new TableColumn<>("" + (c + 1));
		col.setCellValueFactory(param -> new ReadOnlyObjectWrapper<>(param.getValue()[c]));
		return col;
	}

	private ObservableList<Integer[]> generateData(Integer[][] data) {

		ObservableList<Integer[]> items = FXCollections.observableArrayList();

		Integer[] aux = new Integer[data[0].length];

		for (int i = 0; i < data.length; i++) {
			aux = new Integer[data[0].length];
			for (int j = 0; j < data[0].length; j++) {
				aux[j] = data[i][j];
			}
			items.add(aux);
		}

		return items;

	}

	public Controller() {

		btnAddSub = new Button();
		timeUnitSelect = new ComboBox<String>();
		comboTimeUnit = new ComboBox<String>();
		comboFatherPIdentifierMRP = new ComboBox<String>();
		comboParentProductIdentifier = new ComboBox<String>();

	}

}
