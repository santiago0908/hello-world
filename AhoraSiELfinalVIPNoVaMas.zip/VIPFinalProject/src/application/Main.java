package application;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TitledPane;
import javafx.scene.image.Image;
import javafx.stage.Modality;
import javafx.stage.Stage;


public class Main extends Application {
	
	public static Controller controller;
	
	public void start(Stage primaryStage) throws Exception{
		
		
		Parent root = FXMLLoader.load(getClass().getResource("/view/sfs.fxml"));
		Scene scene = new Scene(root);
		Image icon = new Image("file:./img/iconnave.png");
		controller = new Controller();
		
		primaryStage.getIcons().add(icon);
		primaryStage.setScene(scene);
		primaryStage.setTitle(".:::         MRP        :::.");
		primaryStage.setMaximized(false);
		primaryStage.setResizable(false);
		primaryStage.show();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
